package main;
import java.util.*;
import booking.Ticket;
import bus.Bus;
import bus.BusDatabase;
import bus.ACBus;
import bus.NonACBus;
import bus.LuxuryBus;
import exception.InvalidInputException;
import utility.Logger;
import java.util.ArrayList;


public class BusTicketSystem {
	 public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
    ArrayList<Ticket> tickets = new ArrayList<>();
    boolean running=true;

    while (running) {
        System.out.println("**Bus Ticket Management System**");
        System.out.println("1. Display All the buses");
        System.out.println("2. Add Passenger");
        System.out.println("3. Display Passenger Details");
        System.out.println("4. Remove Passenger");
        System.out.println("5. Make Payment");
        System.out.println("6. Exit");
        System.out.print("Choose an option: ");
        int choice = -1;
        try {
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline
        } catch (InputMismatchException e) {
            System.out.println("❌ Invalid input! Please enter a number between 1-6.");
            scanner.nextLine();  // Clear invalid input
            continue;
        }
        
        switch (choice) {
        
        case 1:List<Bus> availableBuses = BusDatabase.getAllBuses();
        if (availableBuses.isEmpty()) {
            System.out.println("No buses available at the moment.");
        } else {
            System.out.println("\n---- Available Buses ----");
            for (Bus bus : availableBuses) {
                bus.displayDetails();
                System.out.println("---------------------------");
            }
        }
        break;
            case 2:
                try {
                    System.out.print("Enter Bus Number: ");
                    String busNumber = scanner.nextLine();
                    
                    // 🔹 Fetch bus from the BusDatabase
                    Bus bus = BusDatabase.getBusByNumber(busNumber);
                    if (bus == null) {
                    	 throw new InvalidInputException("❌ Bus not found! Please enter a valid bus number.");
                    }

                    System.out.print("Enter Passenger Name: ");
                    String name = scanner.nextLine();
                    int age = 0;
                    while (true) {
                        try {
                            System.out.print("Enter Age: ");
                            age = scanner.nextInt();
                            scanner.nextLine(); // 🔹 Consume the leftover newline
                            if (age <= 0) {
                                System.out.println("❌ Age must be a positive number.");
                                continue;
                            }
                            break; // ✅ Exit loop if input is valid
                        } catch (InputMismatchException e) {
                            System.out.println("❌ Invalid input! Age must be a number.");
                            scanner.nextLine(); // 🔹 Clear the invalid input
                        }
                    }

                    System.out.print("Enter Starting Destination: ");
                    String startDestination = scanner.nextLine();
                    System.out.print("Enter Ending Destination: ");
                    String endDestination = scanner.nextLine();
                    System.out.print("Enter Boarding Date (YYYY-MM-DD): ");
                    String boardingDate = scanner.nextLine();

                    String sleeperPosition = "Not Applicable";
                    if (bus.getSeatType().equalsIgnoreCase("Sleeper")) {
                        System.out.print("Enter Sleeper Position (Upper/Lower): ");
                        sleeperPosition = scanner.nextLine();
                    }

                    // 🔹 Allocate seat
                    int seatNumber = bus.allocateSeat(sleeperPosition);
                    if (seatNumber == -1) {
                        System.out.println(" Sorry, no available seats in this section!");
                        continue;
                    }

                    // 🔹 Create and add ticket
                    Ticket ticket = new Ticket(bus, name, age, seatNumber, sleeperPosition, startDestination, endDestination, boardingDate);
                    tickets.add(ticket);
                    System.out.println("✅ Passenger added successfully!");
                 
                } catch (InvalidInputException e) {
                    System.out.println(e.getMessage()); 
                    continue;   // Handling the exception
                } catch (Exception e) {
                    System.out.println("Error: " + e.getMessage()); 
                    continue;   // Handling unexpected errors
                }
                
                break;
                
                
            case 3:
            	if (tickets.isEmpty()) {
                    System.out.println("No passengers booked yet.");
                } else {
                    System.out.println("\n---- Passenger Details ----");
                    double totalFare = 0;
                    for (Ticket t : tickets) {
                        t.displayTicket(); // New method to display passenger details
                        totalFare += t.getFare();
                        System.out.println("---------------------------");
                    }
                  
                }
                break;
            case 4:
                System.out.print("Enter Passenger Name to Remove: ");
                String removeName = scanner.nextLine();
                tickets.removeIf(t -> t.getPassengerName().equalsIgnoreCase(removeName));
                System.out.println("Passenger removed.");
                break;
           

            case 5: // Make Payment and Show Ticket
                if (tickets.isEmpty()) {
                    System.out.println("No passengers booked yet.");
                } else {
                    double totalFare = 0;
                    System.out.println("\n---- Payment Details ----");
                    for (int i = 0; i < tickets.size(); i++) {
                        Ticket t = tickets.get(i);
                        System.out.println("Passenger " + (i + 1) + " (" + t.getPassengerName() + ") Fare: $" + t.getFare());
                        totalFare += t.getFare();
                    }
                    System.out.println("Total Fare: $" + totalFare);
                    System.out.print("Confirm payment? (yes/no): ");
                    String confirmPayment = scanner.nextLine();
                    
                    if (confirmPayment.equalsIgnoreCase("yes")) {
                        System.out.println("Payment Successful!");
                        System.out.println("\n---- Booking Successful! ----");
                        for (Ticket t : tickets) {
                            t.displayTicket();
                            System.out.println("---------------------------");
                        }
                    } else {
                        System.out.println("Payment canceled. Booking not confirmed.");
                    }
                }
                break;
    
                
            case 6:
                running = false;
                System.out.println("Thank you for Booking with us..!!!");
                System.out.println("Have a safe and happy trip........");
                break;
            default:
                System.out.println("Invalid choice!");
        }
    }
    scanner.close();

	
}}
