package bus;

public abstract class Bus {

    protected String busNumber;
    protected String type; // AC or Non-AC
    public String seatType; // Sleeper or Seater
    protected double fare;
    protected int totalSeats;
    protected boolean[] seatAvailability;

    public Bus(String busNumber, String type, String seatType) {
        this.busNumber = busNumber;
        this.type = type;
        this.seatType = seatType;
        this.fare = calculateFare();
        this.totalSeats = seatType.equalsIgnoreCase("Seater") ? 40 : 30;
        this.seatAvailability = new boolean[totalSeats];
        
        for (int i = 0; i < totalSeats; i++) {
            seatAvailability[i] = false;
        }
    }
    
    public abstract double calculateFare(); // Abstract method
    


    public double getFare() { 
        return fare; 
    }
    public String getBusNumber() {
        return busNumber;
    }

    public String getType() {
        return type;
    }

    public String getSeatType() {
        return seatType;
    }


    
    public void displayDetails() {
        System.out.println("Bus Number: " + busNumber);
        System.out.println("Type: " + type);
        System.out.println("Seat Type: " + seatType);
        System.out.println("Fare: " + fare);
    }
    
    public int allocateSeat(String sleeperPosition) {
        int start = 0, end = totalSeats;
        if (seatType.equalsIgnoreCase("Sleeper")) {
            if (sleeperPosition.equalsIgnoreCase("Upper")) {
                start = 15; end = 30;
            } else {
                start = 0; end = 15;
            }
        }
     // Find the first available seat in the given range
        for (int i = start; i < end; i++) {
            if (!seatAvailability[i]) {
                seatAvailability[i] = true;
                return i + 1;// Seat numbers start from 1, not index 0
            }
        }
        return -1; 
    }
}
