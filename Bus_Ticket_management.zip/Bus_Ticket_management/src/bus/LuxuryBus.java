package bus;

public class LuxuryBus extends Bus{
	public LuxuryBus(String busNumber, String seatType) {
        super(busNumber, "Luxury", seatType);
    }
    
    @Override
    public double calculateFare() {
        double baseFare = 700;
        if (seatType.equalsIgnoreCase("Sleeper")) baseFare += 200;
        return baseFare;
    }
}
