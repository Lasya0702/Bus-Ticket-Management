package bus;
//Concrete class for AC Bus
public class ACBus extends Bus {
	 public ACBus(String busNumber, String seatType) {
	        super(busNumber, "AC", seatType);
	    }
	    
	    @Override
	    public double calculateFare() {
	        double baseFare = 500;
	        baseFare += 200;
	        if (seatType.equalsIgnoreCase("Sleeper")) baseFare += 150;
	        return baseFare;
	    }
}
