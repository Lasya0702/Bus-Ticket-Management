package bus;
import java.util.ArrayList;
import java.util.List;

public class BusDatabase {
	private static final List<Bus> buses = new ArrayList<>();

	// Static block to initialize predefined buses
    static {
        // ✅ AC Buses
        buses.add(new ACBus("AC1001", "Seater"));
        buses.add(new ACBus("AC1002", "Sleeper"));
        buses.add(new ACBus("AC1003", "Sleeper"));
        buses.add(new ACBus("AC1004", "Seater"));

        // ✅ Non-AC Buses
        buses.add(new NonACBus("NAC2001", "Seater"));
        buses.add(new NonACBus("NAC2002", "Sleeper"));
        buses.add(new NonACBus("NAC2003", "Sleeper"));
        buses.add(new NonACBus("NAC2004", "Seater"));

        // ✅ Luxury Buses
        buses.add(new LuxuryBus("LX3001", "Sleeper"));
        buses.add(new LuxuryBus("LX3002", "Sleeper"));
        buses.add(new LuxuryBus("LX3003", "Seater"));
        buses.add(new LuxuryBus("LX3004", "Seater"));
    }

    // Fetches  all available buses
    public static List<Bus> getAllBuses() {
        return buses;
    }

    // Find bus by number
    public static Bus getBusByNumber(String busNumber) {
        for (Bus bus : buses) {
            if (bus.getBusNumber().equalsIgnoreCase(busNumber)) {
                return bus;
            }
        }
        return null;
    }
}
