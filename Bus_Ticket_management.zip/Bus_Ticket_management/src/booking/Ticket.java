package booking;
import bus.Bus;
import java.util.ArrayList;


public class Ticket implements Booking{

	    private Bus bus;
	    private String passengerName;
	    private int age;
	    int seatNumber;
	    String sleeperPosition;
	    private String startDestination;
	    private String endDestination;
	    private String boardingDate;
	    int fare;
	    
	    public Ticket(Bus bus, String passengerName, int age, int seatNumber,String sleeperPosition,String startDestination, String endDestination, String boardingDate) {
	       this.bus=bus;
	        this.passengerName = passengerName;
	        this.age = age;
	        this.sleeperPosition = sleeperPosition;
	        this.startDestination = startDestination;
	        this.endDestination = endDestination;
	        this.boardingDate = boardingDate;
	        this.seatNumber=seatNumber; //Assigned automatically
	        this.fare=(int)bus.getFare();
	    }
	    
	    public String getPassengerName() {
	        return passengerName;
	    }
	    
	    public Bus getBus() {
	        return bus;
	    }
	    
	    public double getFare() {
	        return bus.getFare();
	    }
	    
	    @Override
	    public void bookTicket() {
	        System.out.println("Booking Successful!");
	        bus.displayDetails();
	        System.out.println("Passenger: " + passengerName + ", Age: " + age);
	        System.out.println("Seat Number: " + seatNumber);
	        if (bus.seatType.equalsIgnoreCase("Sleeper")) {
	            System.out.println("Sleeper Position: " + sleeperPosition);
	        }
	        System.out.println("From: " + startDestination + " To: " + endDestination);
	        System.out.println("Boarding Date: " + boardingDate);
	        System.out.println("Fare: $" + fare);
	    }
	    
	    public void displayTicket() {
	        System.out.println("Passenger Name: " + passengerName);
	        System.out.println("Age: " + age);
	        System.out.println("Bus Number: " + bus.getBusNumber());
	        System.out.println("Bus Type: " + bus.getType());
	        System.out.println("Seat Type: " + bus.getSeatType());
	        System.out.println("Seat Number: " + seatNumber);
	        if (bus.getSeatType().equalsIgnoreCase("Sleeper")) {
	            System.out.println("Sleeper Position: " + sleeperPosition);
	        }
	        System.out.println("From: " + startDestination + " To: " + endDestination);
	        System.out.println("Boarding Date: " + boardingDate);
	        System.out.println("Fare: $" + getFare());
	    }
}
